import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { apiURL } from '../config'; // Define your API URL in a config file
import { SoucheWrapper } from '../model/SoucheWarpped';
import { Chat } from '../model/chat.model';
import { Souche } from '../model/souche.model';
import { AuthService } from './auth.service'; // Import AuthService if you have one

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private apiURL: string = apiURL + '/chats';
  private apiURLSou: string = apiURL + '/sou';

  constructor(private http: HttpClient, private authService: AuthService) {
    // Initialize your service
  }

  listeChat(): Observable<Chat[]> {
    return this.http.get<Chat[]>(this.apiURL);
  }

  ajouterChat(ch: Chat): Observable<Chat> {
    return this.http.post<Chat>(this.apiURL, ch, this.getHttpOptions());
  }

  supprimerChat(id: number): Observable<any> {
    const url = `${this.apiURL}/${id}`;
    return this.http.delete(url, this.getHttpOptions());
  }

  consulterChat(id: number): Observable<Chat> {
    const url = `${this.apiURL}/${id}`;
    return this.http.get<Chat>(url);
  }

  updateChat(ch: Chat): Observable<Chat> {
    return this.http.put<Chat>(this.apiURL, ch, this.getHttpOptions());
  }

  trierChats() {
    // Your sorting logic
  }

  listeSouches(): Observable<SoucheWrapper> {
    return this.http.get<SoucheWrapper>(this.apiURLSou);
  }

  rechercherParSouche(idSou: number): Observable<Chat[]> {
    const url = `${this.apiURL}/chatsou/${idSou}`;
    return this.http.get<Chat[]>(url);
  }

  rechercherParNom(nom: string): Observable<Chat[]> {
    const url = `${this.apiURL}/chatsByName/${nom}`;
    return this.http.get<Chat[]>(url);
  }

  ajouterSouche(sou: Souche): Observable<Souche> {
    return this.http.post<Souche>(this.apiURLSou, sou, this.getHttpOptions());
  }

  // Add a method to get HTTP headers with an authentication token
  private getHttpOptions(): { headers: HttpHeaders } {
    const jwt = this.authService.getToken();
    const headers = new HttpHeaders({ 'Authorization': `Bearer ${jwt}` });
    return { headers };
  }
}
