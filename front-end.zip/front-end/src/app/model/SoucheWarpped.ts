import { Souche } from './souche.model';
export class SoucheWrapper{
_embedded!: { souches: Souche[]};
}