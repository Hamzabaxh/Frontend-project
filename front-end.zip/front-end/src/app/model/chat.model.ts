import { Souche } from "./souche.model";

export class Chat {
    idChat? : number;
    nomChat? : string;
    prixAdoption? : number;
    datenaissance? : Date ;
    coulour? : string;
    souche? : Souche;
    }